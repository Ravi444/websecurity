
use(function () {

    var image1 = properties.get("image1", "");
    var image2 = properties.get("image2", "");
    var image3 = properties.get("image3", "");
  
    return {

        img1: image1,
        img2: image2,
        img3: image3,

    };
});